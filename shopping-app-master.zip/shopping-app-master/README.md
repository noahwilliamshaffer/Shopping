# Shopping App
![Website Preview](background.png)
This is a functional shopping app intended to be a clone of Amazon and some of its features. This  clone is mixed with my design style and features that I thought would make it look better. This was created with React and incorporates Firebase Cloud Firestore, Firebase authentication, and accepts payments through Stripe.
